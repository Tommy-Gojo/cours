/*
    Pour javascript, vous nommerez vos variable en lowerCamelCase
    var maSuperVariable
    function maSuperFonction (){
        // Instruction
    }
    Seule les classes seront écrite en UpperCamelCase 
    MaSuperClasse
    Pensez à nommez correctement vos variable fonction pour comprendre
    directement, ce qu'elle fait. 
    Cela simplifiera la relecture. 

    N'oubliez pas Lors de la création de votre repository distant votreNom - Mes exercices JavaScript
    Cela me simplifiera la vie lors des correction MERCI !
*/
